//
//public class Main {
//    public static void main(String[] args) {
//
//        String one = "longest";
//        String two = "stone";
//        lcs(one, two);
//        one = "BANANA";
//        two = "ATANA";
//        lcs(one, two);
//        one = "ABC";
//        two = "DEF";
//        lcs(one, two);
//    }
//    public static void lcs(String stringOne, String stringTwo) {
//        if (stringOne.length() < stringTwo.length()) {
//            String temp = stringOne;
//            stringOne = stringTwo;
//            stringTwo = temp;
//        }
//        int lengthS1 = stringOne.length();
//        int lengthS2 = stringTwo.length();
////        if (lengthS2 > lengthS1){
////            String temp = stringOne;
////            stringOne = stringTwo;
////            stringTwo = temp;
////        }
////        lengthS1 = stringOne.length();
////        lengthS2 = stringTwo.length();
////        System.out.println(lengthS2);
////        System.out.println(lengthS1);
//        int[][] array;
//        if (lengthS1 >= lengthS2) {
//            ;
//        } else {
//            System.out.println("ERROR");
//        }
//        array = new int[lengthS2 + 1][lengthS1 + 1];
////        for (int y = 1; y < lengthS1+1; y++){
////            for (int x = 1; x < lengthS2+1; x++){
////                if (stringOne.charAt(y) == stringTwo.charAt(x)){
////                    array[y][x] = array[y-1][x-1] +1;
////                }
////                else{
////                    if(array[y-1][x] > array[y][x-1]){
////                        array[y][x] = array[y-1][x];
////                    }
////                    else{
////                        array[y][x] = array[y][x-1];
////                    }
////
////                }
////            }
////        }
////        for (int i = 0; i < lengthS2 + 1; i++) {
////            for (int j = 0; j < lengthS1 + 1; j++) {
////                System.out.print(array[i][j]);
////            }
////            System.out.println("");
////        }
//        for (int i = 1; i < lengthS2 + 1; i++) {
//            for (int j = 1; j < lengthS1 + 1; j++) {
////                System.out.println(stringOne.charAt(j - 1) + " " + stringTwo.charAt(i - 1));
//                if (stringOne.charAt(j - 1) == stringTwo.charAt(i - 1)) {
////                    System.out.println("here");
////                    System.out.println("array[j][i]" + array[j-1][i-1]);
////                    System.out.println("here1");
////                    array[i][j] = 9;
//                    array[i][j] = array[i - 1][j - 1] + 1;
////                    for (int x = 0; x < lengthS2 + 1; x++) {
////                        for (int y = 0; y < lengthS1 + 1; y++) {
////                            System.out.print(array[x][y]);
////                        }
////                        System.out.println("");
////                    }
////                    if (array[j - 1][i - 1] > array[j][i]) {
////                        System.out.println("here");
////
////                        array[j][i] = array[j-1][i-1] + 1;
//////                        count++;
////                    } else {
////                        array[j][i] = 1;
////                    }
//                } else if (array[i - 1][j] > array[i][j - 1]) {
//                    array[i][j] = array[i - 1][j];
//                } else {
//                    array[i][j] = array[i][j - 1];
//                }
//            }
//        }
//        String match = "";
//        int lengthOfSubString = array[lengthS2][lengthS1];
////        System.out.println(lengthOfSubString);
////        int l1 = lengthS1;
////        int l2 = lengthS2;
////        while(lengthOfSubString != 0){
////            if(array[lengthS2-1][lengthS2-1] !=array[lengthS2-1][lengthS2]){
////                if(array[lengthS2-1][lengthS2-1] != array[lengthS2][lengthS2]){
////                    match += stringOne.charAt(lengthS1);
////                    lengthOfSubString--;
////                    l1--;
////                }
////            }
////            else{
////                l2--;
////            }
////        }
//        FOUND:
//        for (int i = lengthS2; i > 1; i--) {
//            for (int j = lengthS1; j > 1; j--) {
//                if (array[i][j - 1] == array[i - 1][j] && array[i - 1][j] == array[i - 1][j - 1] && array[i - 1][j - 1] != array[i][j]) {
//                    match += stringOne.charAt(j - 1);
//                    if (array[i - 1][j - 1] == 0) {
//                        break FOUND;
//                    }
//                    break;
//                }
//            }
//        }
//        System.out.println("");
//        for (int x = 0; x < lengthS2 + 1; x++) {
//            for (int y = 0; y < lengthS1 + 1; y++) {
//                System.out.print(array[x][y]);
//            }
//            System.out.println("");
//        }
////        System.out.println(match);
//        String LCSFound = "";
//
//        for (int i = 0; i < match.length(); i++) {
//            LCSFound = match.charAt(i) + LCSFound;
//        }
//        System.out.println("Words Used:  " + stringOne + " and "+ stringTwo);
//        System.out.println("Longest Common Subsequence found: " + LCSFound);
////        for (int i = 0; i < lengthS1; i++) {
////            for (int j = 0; j < lengthS2; j++) {
////                if (stringOne.charAt(i) == stringTwo.charAt(j)) {
////                    if (array[j][i] == count) {
////                        array[j + 1][i + 1] = count + 1;
////                        count++;
////                    } else {
////                        array[j + 1][i + 1] = 1;
////                    }
////                } else if (array[j][i + 1] > array[j + 1][i]) {
////                    array[j + 1][i + 1] = array[j][i + 1];
////                } else if (array[j][i + 1] <= array[j + 1][i]) {
////                    array[j + 1][i + 1] = array[j + 1][i];
////                }
////            }
////        }
////        if (count == 0) {
////            System.out.println("no match found");
////            return;
////        }
////        int totalCount = count;
////        for (int i = lengthS1; i > 0; i--) {
////            for (int j = lengthS2; j > 0; j--) {
////                System.out.print(stringOne.charAt(i - 1));
////                if (count == 0) {
////                    break;
////                } else if (array[j-1][i] == array[j][i - 1] && array[j][i] == count && array[j ][i] == count - 1) {
////                    count--;
////                    match += stringOne.charAt(lengthS1 - j - 1);
////                }
////            }
////        }
////        System.out.println("Match is : " + match + ". Total length is: " + totalCount);
////        for (int i = 0; i < lengthS2 + 1; i++) {
////            for (int j = 0; j < lengthS1 + 1; j++) {
////                System.out.print(array[i][j]);
////            }
//    }
//}
